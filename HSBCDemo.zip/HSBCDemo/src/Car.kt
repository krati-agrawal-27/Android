class Car :Vehicle() { //:vehicle to inherit the class
    override fun move() { //overriding the function
        println("car moves")
    }
}