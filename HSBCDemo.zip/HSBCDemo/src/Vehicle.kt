open class Vehicle() { //open so that can be inherited
    open fun move() { //open so that can be overridden
        println("Vehicle moves")
    }
}