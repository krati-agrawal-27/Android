import java.util.*
import java.util.Scanner

fun main(args: Array<String>) {
    println("Hello World")
    var a = 9 //a is underlined bcoz var
    println(a)
    val b: Int = 99 //b is val hence not underlined
    println(b)
    println("a=$a and b=$b") //kotlin way
    println("a=" + a + " b=" + b) //java way
    println(a + b)
    a = 10 //we can change value of a but not of b(val)
    println(a)
    // can reformat code by code -> reformat code OR Ctrl+Alt+L
    if (a > 10) {
        println("greater")
    } else {
        if (a == 10) {
            println("equal")
        } else println("lesser")
    } // demo of if loop
    println("Enter your percentage")
    val c: Int = Integer.valueOf(readLine()) //To take input
    if (c > 35) {
        println("you passed")
    } else {
        println("you failed")
    }
    val reader = Scanner(System.`in`) // input using scanner
    print("Enter a number: ")
    var integer: Int = reader.nextInt()
    println("You entered: $integer")
    print("Enter a double value: ") // input for double
    val string2 = readLine()!!
    var doubleValue: Double = string2.toDouble()
    println("You entered: $doubleValue")

    var d: Int = 4 //Switch == when
    when (d) {
        1 -> println("case 1")
        2 -> println("case 1")
        in 3..10 -> println("case 3")
        else -> println("Default")
    }
    println("")
    var i: Int = 1
    while (i <= 10) {
        print(i)
        i++
    } //while loop
    println("")

    for (e in 1..10) {
        print(e)
    } // for loop
    println("")

    for (e in 10 downTo 1) {
        print(e)
    } // for loop downto ie reverse
    println("")

    println("Enter no to find its factorial")
    val f: Int = Integer.valueOf(readLine())
    var g: Int = 1
    for (e in 2..f) {
        g *= e
    }
    println("your factorial is $g")
    println("")

    var arr: Array<Int> = arrayOf(10, 4, 12, 7) //arrays
    for (x in arr) {
        print(x)
    }
    println("")
    for (x in arr.indices) {
        print(arr[x])
    }

    println("")
    println("Enter a number to check if it is prime")
    val h: Int = Integer.valueOf(readLine())

    for (x in 2 until h) {
        if (h % x == 0) {
            println("not a prime")
            break;
        }
        if (x == h - 1) println("prime no")
    }


}