fun main(args: Array<String>) {
    hello()
    println(add(b = 1, a = 1))
    var e: Employee = Employee(123, "abc", 123456.0, 1000.0)
    e.printEmp()
    var v: Vehicle = Vehicle();
    v.move();
    var c: Car = Car()
    c.move()
}

fun hello() {
    println("Hello")
}

fun add(a: Int, b: Int): Int {
    return a + b
}