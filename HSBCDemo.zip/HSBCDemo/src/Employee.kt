class Employee(_emplid: Int, _ename: String, _basicsalary: Double, _medical: Double) {
    var empid: Int = 0
    lateinit var ename: String
    var basicsalary: Double = 0.0
    var medical: Double = 0.0
    var PF: Double = .12 * basicsalary

    var PT: Double = 200.0
    var HRA: Double = .5 * basicsalary


    init {
        empid = _emplid
        ename = _ename
        basicsalary = _basicsalary
        medical = _medical
    }

    var gross: Double = basicsalary + HRA + medical
    var netsalary: Double = gross - PF - PT
    fun printEmp() {
        println("ID= $empid, Name= $ename, Salary=$basicsalary")
        println("your gross salary is $gross and net salary is $netsalary")
    }

}